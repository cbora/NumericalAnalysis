function g = partialPivoting(mat)
	%n = rows(mat);
    n = 10;
	g = zeros(1,n);
	for i = 1:n
		j = i;
		p = 0;
		while(j<=n)
			if(p==0||abs(mat(j,i)) > abs(mat(p,i)))
				p = j;
            end
			j=j+1;
        end
		if(p==0)
			disp('No unique solution exists');
			g=-1;
			return;
		elseif(p~=i)
			fprintf('Row interchange: %3f  with %3f\n',i,p);
			temp = mat(p,:);
			mat(p,:)=mat(i,:);
			mat(i,:)=temp;
        end
		for k = (i+1):n
			mki = mat(k,i)/mat(i,i);
			mat(k,:) = mat(k,:) - mki*mat(i,:);
        end
    end
	if(mat(n,n)==0)
		disp('No unique solution exists');
		g=-1;
		return;
    end
	g(n) = mat(n,n+1)/mat(n,n);
	i = n-1;
	while(i>=1)
		sum = 0;
		for j=i+1:n
			sum = sum + mat(i,j)*g(j);
        end
		g(i) = (mat(i,n+1)-sum)/mat(i,i);
		i = i-1;
    end
       
